/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula2404;

/**
 *
 * @author aluno
 */
public class Aula2404 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
