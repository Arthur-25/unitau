package ex1;

import java.util.Scanner;

public class ex1 {
    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        funcionario F = new funcionario();
        F.funcionarios_abaixo = 0;
        String escolha;
        while (true) {
            System.out.println("Digite quantas horas você trabalha");
            F.horas = sc.nextInt();
            System.out.println(F.calcula_salario());

            System.out.println("Quer continuar registrando? S/N");
            escolha = sc.next();

            if (escolha.matches("N")){
                break;
            }
        }
        System.out.println("Quantidade de pessoas que recebem menos que 3500: " + F.funcionarios_abaixo);
    }
}
