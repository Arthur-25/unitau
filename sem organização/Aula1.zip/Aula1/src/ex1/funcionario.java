package ex1;

public class funcionario {
    int horas;
    int funcionarios_abaixo;

    public double calcula_salario(){
        double salario = horas*25;
        if (salario>3500){
            salario = salario - ((salario*10)/100);
        }
        if (salario<3500){
            funcionarios_abaixo++;
        }
        return salario;
    }
}
