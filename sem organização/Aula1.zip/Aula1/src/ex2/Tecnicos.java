package ex2;

public class Tecnicos {
    int[] codPessoa = new int[20];
    int[] numTecnico = new int[20];
}
