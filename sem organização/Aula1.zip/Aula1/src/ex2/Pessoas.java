package ex2;

public class Pessoas {
    int[] codPessoa = new int[20];
    String[] Pessoa = new String[20];
}
