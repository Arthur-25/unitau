package ex2;

public class Atendentes {
    int[] codPessoa = new int[20];
    int[] numAtendente = new int[20];

}
