package ex2;

import java.util.Scanner;

public class ex2 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        Clientes C = new Clientes();
        int count = 0;
        String resp;
        int sel;


        while(true){
            System.out.println("Deseja cadastrar ou consultar?");
            resp = sc.next();
            if (resp.matches("cadastrar")){
                System.out.println("Digite: Nome da pessoa ");
                resp = sc.next();
                C.setCadastrar(count,count,count,resp,count,count);
            }else if (resp.matches("consultar")){
                System.out.println("Digite: codigo da pessoa ");
                sel = sc.nextInt();
                C.getConsultar(sel);
            }

            System.out.println("Deseja continuar? S/N");
            resp = sc.next();
            if (resp.matches("N")){
                break;
            }else{
                if (count<20){
                    count++;
                }
            }

        }

    }
}
