package ex2;

public class Clientes {
    int[] codPessoa = new int[20];
    int[] numCliente = new int[20];
    Atendentes A = new Atendentes();
    Pessoas P = new Pessoas();
    Tecnicos T = new Tecnicos();

    public void setCadastrar(int N1, int cod, int num, String nome, int codigoT,int codigoA){

        codPessoa[N1] = cod;
        numCliente[N1] = num;
        P.Pessoa[N1] = nome;
        T.numTecnico[N1] = codigoT;
        A.numAtendente[N1] = codigoA;
    }
    public void getConsultar(int N1){
        for (int i = 0; i<20;i++){
            if (i == N1){
                System.out.println("Numero do cliente: " + numCliente[N1]);
                System.out.println("Nome do cliente: " + P.Pessoa[N1]);
                System.out.println("Numero do atendente: " + A.numAtendente);
                System.out.println("Numero do tecnico: " + T.numTecnico[N1]);
            }
        }
    }
}
