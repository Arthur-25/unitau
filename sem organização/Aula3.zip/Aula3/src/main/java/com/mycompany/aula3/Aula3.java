/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula3;

/**
 *
 * @author aluno
 */
public class Aula3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
