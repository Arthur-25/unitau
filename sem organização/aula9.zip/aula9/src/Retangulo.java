public class Retangulo {
    public static double altura;
    public static double largura;

    public static double calculaArea(double altura, double largura){
        return altura*largura;
    }
}
