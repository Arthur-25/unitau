public class Carro {
    public String marca;
    public String modelo;
    public int ano;

    public static void exibirInformacoes(String marca, String modelo, int ano){
        System.out.println("Marca: " + marca + " modelo: "+modelo+" ano: "+ano);
    }
}
