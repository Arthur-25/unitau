public class Produto {
    public String nome;
    public double preco;

    public static double aplicarDesconto(double desconto, double preco){
        return preco - ((preco*desconto)/100);
    }
}
