public class Aaluno {
    public static String nome;
    public static int[] notas;

    public static double calculaMedia(int[] notas){
        double media = 0;
        for (int i = 0;i<notas.length;i++){
            media += notas[i];
        }
        return media;
    }
}
