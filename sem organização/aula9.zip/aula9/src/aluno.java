public class aluno {
    public String nome;
    public double nota;

    public static String verificarAprovacao(double nota){
        if (nota>= 6){
            return "Aprovado";
        }else{
            return "Não aprovado";
        }
    }
}
