package exercicio2;

public class empregado {
    public int anonascimento;
    public int anoingresso;
    public int codigo;

    public  int empregados;

    public static String verifica_empregado(int ano, int anonasc){
            int idade = 2024 - anonasc;
            int tempo = 2024 - ano;

            if (idade>= 65){
                return "Requerer aposentadoria";
            }
            if (tempo>= 30){
                return "Requerer aposentadoria";
            }
            if (idade>=60 && tempo>=25){
                return "Requerer aposentadoria";
            }

            return "Não Requerer ";
    }
}
