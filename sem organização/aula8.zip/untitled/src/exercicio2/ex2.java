package exercicio2;

import java.util.Scanner;

public class ex2 {

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String R;
        empregado E = new empregado();
        E.empregados = 0;
        while (true){
            System.out.println("Digite seu codigo, ano de nascimento, ano de ingresso na empresa");
            E.codigo = sc.nextInt();
            E.anonascimento = sc.nextInt();
            E.anoingresso = sc.nextInt();

            System.out.println(E.verifica_empregado(E.anoingresso,E.anonascimento));
            if (2024 - E.anonascimento<65 && 2024 - E.anoingresso>= 30){
                E.empregados++;
            }
            System.out.println("Deseja continuar cadastrando?");
            R = sc.next();

            if (R.matches("não") || R.matches("n")){
                break;
            }
        }
        System.out.println("Quantidade de empregados com 30 anos de trabalho, abaixo de 65 anos: " + E.empregados);

    }
}
