package exercicio5;

import java.util.Scanner;

public class ex5 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String R;
        funcionario F = new funcionario();
        F.quantidade = 1;
        while (true){
            System.out.println("Digite seu salario");
            F.salario = sc.nextDouble();
            F.total_salarios += F.salario;

            System.out.println("Deseja continuar cadastrando?");
            R = sc.next();

            if (R.matches("não") || R.matches("n")){
                break;
            }
            F.quantidade++;
        }
        System.out.println("Media dos salarios: " + F.media_salarial(F.total_salarios,F.quantidade));
    }
}
