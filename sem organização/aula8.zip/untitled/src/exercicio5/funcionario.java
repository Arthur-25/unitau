package exercicio5;

public class funcionario {
    public int quantidade;
    public double salario;
    public double total_salarios;

    public static double media_salarial(double sal, int quant){
        return sal/quant;
    }
}
