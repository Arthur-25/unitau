package exercicio4;

public class funcionario {
    public String nome;
    public int idade;
    public String cargo;
    public double salario;

    public static double reajuste(double sal){
        sal += (sal*38)/100;
        sal += (sal*20)/100;
        sal -= (sal*15)/100;
        return  sal;
    }
}
