package exercicio4;

import java.util.Scanner;

public class ex4 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        funcionario func = new funcionario();

        System.out.println("Digite seu Nome, idade cargo e o seu salário bruto");
        func.nome = sc.next();
        func.idade = sc.nextInt();
        func.cargo = sc.next();
        func.salario = sc.nextDouble();


        System.out.println("Nome,idade e cargo: " + func.nome + ", " + func.idade + ", " + func.cargo);
        System.out.println("Salario bruto" + func.salario);
        System.out.println("Salario liquido " + func.reajuste(func.salario));


    }
}
