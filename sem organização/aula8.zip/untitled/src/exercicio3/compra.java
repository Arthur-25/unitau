package exercicio3;

public class compra {
    int codigo_cupom;
    double valor_compra;

    public static double valor_final(int cod, double valor){
        if (cod == 100){
            return valor - (valor*20)/100;
        }
        if (cod == 200){
            return valor - (valor*25)/100;
        }
        if (cod == 300){
            return valor - (valor*30)/100;
        }

        return valor - (valor*15)/100;
    }
}
