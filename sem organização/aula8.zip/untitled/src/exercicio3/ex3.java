package exercicio3;

import java.util.Scanner;

public class ex3 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        compra C = new compra();

        System.out.println("Digite  o valor de sua compra");
        C.valor_compra = sc.nextDouble();
        if (C.valor_compra<= 400){
            C.codigo_cupom = 100;
        } else if (C.valor_compra>400 && C.valor_compra<=600){
            C.codigo_cupom = 200;
        }else if (C.valor_compra>600 && C.valor_compra<=850){
            C.codigo_cupom = 300;
        }else {
            C.codigo_cupom = 0;
        }

        System.out.println(C.valor_final(C.codigo_cupom, C.valor_compra));


    }
}
