package exercicio1;

import java.util.Scanner;

public class ex1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        prest sal = new prest();
        System.out.println("Digite seu salario ");
        sal.salario = sc.nextDouble();
        System.out.println("Digite o valor da prestação");
        sal.prestacao = sc.nextDouble();

        System.out.println(sal.verifica_valor(sal.salario,sal.prestacao));

    }
}
