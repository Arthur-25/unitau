package exercicio1;

import java.util.Scanner;

public class prest {
    public double salario;
    public double prestacao;

    public static String verifica_valor(double valor_salario,double valor_prestacao){
       double porc_salario = (valor_salario*20)/100;

       if (porc_salario<valor_prestacao){
           return "Empréstimo não pode ser concedido";
       }else{
           return "Empréstimo pode ser concedido.";
       }
    }
}
