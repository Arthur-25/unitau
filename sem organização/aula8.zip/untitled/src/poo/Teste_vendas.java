package poo;

public class Teste_vendas {
    public static void main(String[] args){
        vendas objeto_venda = new vendas();

        objeto_venda.cliente= "Luis de Souza";
        objeto_venda.produto = "jogo";
        objeto_venda.valor = 320.30;

        System.out.println("\n Cliente: " + objeto_venda.cliente+
                           "\n Produto: " + objeto_venda.produto+
                            "\n Valor: " + objeto_venda.valor);
    }
}
