package poo;

public class vendas {
    public String cliente;
    public String produto;
    public double valor;
}
