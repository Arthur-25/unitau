import java.util.Scanner;

public class ex3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int ano,placa;
        String modelo,cor;
        int corv = 0;
        int anoa =0;
        int modeloonix = 0;

        for (int i = 0; i < N;i++){
            System.out.println("Digite o modelo,ano de fabricação,cor e a placa de seu carro");
            modelo = sc.next();
            ano = sc.nextInt();
            cor = sc.next();
            placa = sc.nextInt();

            if (modelo.matches("onix")){
                modeloonix++;
            }
            if (cor.matches("verde")){
            corv++;
            }
            if (ano<2020){
                anoa++;
            }
        }
        System.out.println("Quantidade de onix: " + modeloonix + " porcentagem comparado ao total: " + (modeloonix*100)/N);
        System.out.println("Quantidade de verdes: " + corv + " porcentagem comparado ao total: " + (corv*100)/N);
        System.out.println("Quantidade de modelos antes de 2020: " + anoa + " porcentagem comparado ao total: " + (anoa*100)/N);
    }
}
