import java.util.Scanner;

public class ex2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double valorcompra,totalvista,totalprazo,totalcompra;
        int codigo,N;
        totalvista = 0;
        totalprazo = 0;
        totalcompra = 0;
        N = sc.nextInt();
        for (int i = 0;i<N;i++){
            System.out.println("Digite se sua compra é a vista ou a prazo 1/2");
            codigo = sc.nextInt();

            System.out.println("Digite o valor da compra");
            valorcompra = sc.nextDouble();
            totalcompra += valorcompra;

            if (codigo == 1){
                totalvista += valorcompra;
            }else{
                totalprazo += valorcompra;
            }
        }

        System.out.println("Total das compras vista:" + totalvista);
        System.out.println("Total das compras prazo:" + totalprazo);
        System.out.println("Total das compras :" + totalcompra);
    }
}
