import java.util.Scanner;

public class ex1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int[] N = new int[10];
        System.out.println("Digite um valor de referencia");
        int n = sc.nextInt();
        System.out.println("Digite 10 numeros");
        int num =0;
        for (int i = 0; i<10;i++){
            N[i] = sc.nextInt();
            if (N[i]<n){
                num++;
            }
        }
        System.out.println("Quantidade de numeros menor que o valor referencia: " + num);

    }
}
