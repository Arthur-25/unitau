package ex2;


public class ex2 {
    public static void main(String[]args){
        produto L = new produto();
        L.preco = 100;
        L.aumentaPreco();
        System.out.print(L.preco);
    }
}
