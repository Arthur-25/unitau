package ex2;

public class produto {
    public double preco;

    public void aumentaPreco(){
        this.preco += (this.preco*20)/100;
    }
}
