package ex4;

public class Conta {
    public int diasAtraso;
    public double valorConta;

    public double calcularMulta(){
        if (this.diasAtraso <= 5){
            return this.valorConta + (this.valorConta*5)/100;
        }else{
            return this.valorConta + (this.valorConta*10)/100;
        }
    }
}
