package ex4;

public class ex4 {
    public static void main(String[]args){
        Conta C = new Conta();
        C.diasAtraso = 7;
        C.valorConta = 100;
        System.out.print(C.calcularMulta());
    }
}
