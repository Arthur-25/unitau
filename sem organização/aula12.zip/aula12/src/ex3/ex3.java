package ex3;

public class ex3 {
    public static void main(String[]args){
        Funcionario F = new Funcionario();
        F.salario = 100;
        System.out.println(F.calculaImposto());
    }
}
