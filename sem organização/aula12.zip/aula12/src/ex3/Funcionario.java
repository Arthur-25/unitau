package ex3;

public class Funcionario {
    public double salario;

    public double calculaImposto(){
        return (this.salario*10)/100;
    }
}
