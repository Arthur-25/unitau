package ex1;

public class ex1 {
    public static void main(String[]args){
        Livro L = new Livro();
        L.preco = 100;
        L.calculaPrecoComAumento();
        System.out.print(L.preco);
    }
}
