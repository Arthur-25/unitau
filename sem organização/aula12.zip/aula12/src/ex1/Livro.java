package ex1;

public class Livro {
    public double preco;

    public void calculaPrecoComAumento(){
        this.preco += (this.preco*15)/100;
    }
}
