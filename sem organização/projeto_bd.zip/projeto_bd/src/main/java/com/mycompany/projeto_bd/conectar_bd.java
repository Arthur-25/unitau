/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto_bd;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.*;

public class conectar_bd {
    private static final String URL = "jdbc:mysql://localhost:3306/Controle_dados";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static Connection conexao;
    
    public static Connection getConnection() throws SQLException {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conexao;
    }//fim da função que abre conexão

    public static void closeConnection() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
            conexao = null;
        }
    }//fim da função que fecha conexão
    
    public static void criar(String nome_cliente, String cpf_cliente) {
        String sql = "INSERT INTO cliente (nome, cpf) VALUES (?, ?)";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
            PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome_cliente);
            pstmt.setString(2, cpf_cliente);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Cliente criado com sucesso!");
            
        } catch (SQLException e) {
            System.err.println("Erro ao criar cliente: " + e.getMessage());
        }
    }//fim da função inserir
    
    public static ArrayList<cliente> buscarTodos() {
        ArrayList<cliente> clientes = new ArrayList<>();
        String sql = "SELECT cliente_id, nome, cpf FROM cliente";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             Statement stmt = conexao.createStatement(); // Para SELECT sem parâmetros, Statement é suficiente
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                clientes.add(new cliente(rs.getInt("cliente_id"), rs.getString("nome"), rs.getString("cpf")));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todos os clientes: " + e.getMessage());
        }
        return clientes;
    }//fim função select todos
    
    public static void atualizar(int id_cliente, String novo_nome, String novo_cpf) {
        String sql = "UPDATE cliente SET nome = ?, cpf = ? WHERE cliente_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, novo_nome);
            pstmt.setString(2, novo_cpf);
            pstmt.setInt(3, id_cliente);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Cliente atualizado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum cliente encontrado com o ID fornecido para atualização.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar cliente: " + e.getMessage());
        }
    }//fim da função atualizar
    
    public static void deletar(int id_cliente) {
        String sql = "DELETE FROM cliente WHERE cliente_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, id_cliente);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Cliente deletado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum cliente encontrado com o ID fornecido para exclusão.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar cliente: " + e.getMessage());
        }
    }//fim da função deletar
        
    
}
