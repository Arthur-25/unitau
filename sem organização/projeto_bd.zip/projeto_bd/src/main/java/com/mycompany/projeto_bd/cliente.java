/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto_bd;

/**
 *
 * @author arthur
 */
public class cliente {
    public cliente(int i, String n, String c){
        cliente_id = i;
        nome = n;
        cpf = c;
    }
    public String nome;
    public String cpf;
    public int cliente_id;
    
}
