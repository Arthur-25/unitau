import java.util.Scanner;

public class ex4 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String[] nomes = new String[10];
        int[] matriculas = new int[10];
        int matricula;

        System.out.println("Digite os nomes e matriculas dos alunos");
        for (int i = 0; i<nomes.length;i++){
            System.out.println("Digite o nome");
            nomes[i] = sc.next();
            System.out.println("Digite a matricula");
            matriculas[i] = sc.nextInt();
        }
        System.out.println("Digite uma matricula para buscar");
        matricula = sc.nextInt();

        boolean e = false;
        int n = 0;
        for (int i = 0; i<matriculas.length;i++){
            if (matriculas[i] == matricula){
                e = true;
                n = i;
            }
        }

        if (e == true){
            System.out.println("Aluno encontrado: " + nomes[n]);
        }else{
            System.out.println("Aluno não encontrado");
        }

    }
}
