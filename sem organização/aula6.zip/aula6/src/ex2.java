import java.util.Scanner;

public class ex2 {
    public static void main(String[] args){
        Scanner valor = new Scanner (System.in);
        int[] vetor = new int[8];
        int[] preco = new int[8];
        int i;

        for(i=0;i<vetor.length;i++)
        {
            System.out.println("Informe o codigo e o preço do livro a ser procurado");
            System.out.println("Codigo:");
            vetor[i] = valor.nextInt();
            System.out.println("Preço:");
            preco[i] = valor.nextInt();

        }


        System.out.println("Informe o codigo do livro a ser procurado");

        int procurado= valor.nextInt();

        boolean achou = false;
        int inicio = 0;
        int fim = vetor.length -1;
        int meio=0;
        while (inicio<=fim)
        {
            meio=(int)((inicio+fim)/2);
            if (vetor[meio]==procurado)
            {
                achou=true;
                break;
            }
            else if(vetor[meio]<procurado)
            {
                inicio = meio + 1;
            }
            else
                fim = meio -1;
        }
        if (achou==true)
        {
            System.out.println(" Livro encontrado, preço: "+preco[meio]);
        }else
        {
            System.out.println(" Livro não encontrado");
        }
    }
}

