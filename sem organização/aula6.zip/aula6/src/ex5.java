import java.util.Arrays;
import java.util.Scanner;

public class ex5 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[10];
        double soma = 0;
        System.out.println("Digite os 10 numeros");

        for (int i = 0;i<numeros.length;i++){
            numeros[i] = sc.nextInt();
            soma += numeros[i];
        }
        Arrays.sort(numeros);


        int maior = 0;
        int menor = 999999999;

        for (int i = 0;i<numeros.length;i++){
            if (numeros[i]>maior){
                maior = numeros[i];
            }
            if (numeros[i]<menor){
                menor = numeros[i];
            }

        }
        System.out.println("Vetor em ordem crescente  ");
        for (int i = 0;i<numeros.length;i++){
            System.out.print(", ");
            System.out.print(numeros[i] );
        }
        System.out.print(".");
        System.out.println("\n Media dos numeros no vetor: " + soma/10);
        System.out.println("Maior numero do vetor: " + maior + " \nmenor numero do vetor: " + menor);

    }
}
