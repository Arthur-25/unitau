import java.util.Scanner;

public class ex3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int[] vetor = new int[10];
        int N,n;
        n = 0;
        boolean e = false;
        System.out.println("Digite os numeros do vetor");
        for (int i = 0; i< vetor.length;i++){
            vetor[i] = sc.nextInt();
        }
        System.out.println("Digite o numero a ser procurado no vetor");
        N = sc.nextInt();

        for (int i = 0; i< vetor.length;i++){
            if (vetor[i] == N){
                e = true;
                n = i;
            }
        }

        if (e == true){
            System.out.println("Numero encontrado na posição: " + n );
        }else {
            System.out.println("Numero não encontrado");
        }
    }
}
