import java.util.Scanner;

public class ex1 {
    public static void main(String[] args){
        int[] vetor = new int[8];
        int i;
        for(i=0;i<vetor.length;i++)
        {
            vetor[i] = i * 2;
            System.out.println(vetor[i]);
        }


        System.out.println("Informe o valor a ser procurado");
        Scanner valor = new Scanner (System.in);
        int procurado=valor.nextInt();

        boolean achou = false;
        int inicio = 0;
        int fim = vetor.length -1;
        int meio=0;
        while (inicio<=fim)
        {
            meio=(int)((inicio+fim)/2);
            if (vetor[meio]==procurado)
            {
                achou=true;
                break;
            }
            else if(vetor[meio]<procurado)
            {
                inicio = meio + 1;
            }
            else
                fim = meio -1;
        }
        if (achou==true)
        {
            System.out.println(" Elemento encontrado, posição"+meio);
        }else
        {
            System.out.println(" Elemento não encontrado");
        }
    }
}

