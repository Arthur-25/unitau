package ex3;

public class Funcionario {
    public double salario;

    public void calculaImposto(){
        if (this.salario <= 2000){
            this.salario -= (this.salario*5)/100;
        }else  if (this.salario >= 2001 && this.salario <= 3500){
            this.salario -= (this.salario*10)/100;
        }else  if (this.salario >3500){
            this.salario -= (this.salario*15)/100;
        }
    }
}
