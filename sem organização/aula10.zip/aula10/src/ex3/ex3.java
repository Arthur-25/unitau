package ex3;

import java.util.Scanner;

public class ex3 {
    public static void main(String[]args){
        Funcionario F = new Funcionario();
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite seu salario");
        F.salario = sc.nextDouble();
        F.calculaImposto();
        System.out.println(F.salario);
    }
}
