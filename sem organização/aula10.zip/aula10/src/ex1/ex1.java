package ex1;

import java.util.Scanner;

public class ex1 {
    public static void main(String[]args){
        Mes M = new Mes();
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite os codigos de lingua e mês");
        M.codigoLingua = sc.nextInt();
        M.codigoMes = sc.nextInt();
        M.getMesPorExtenso(M.codigoMes,M.codigoLingua);
        System.out.println(M.nomeMes);
    }
}
