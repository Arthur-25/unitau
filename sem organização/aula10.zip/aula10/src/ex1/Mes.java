package ex1;

public class Mes {
    public String nomeMes;
    public int codigoMes;
    public int codigoLingua;

    public  void getMesPorExtenso(int codmes, int codlingua){
        String nomeMes = "Janeiro";

        if (codlingua == 1){
            switch (codmes){
                case 1:
                    nomeMes = "Janeiro";
                    break;
                case 2:
                    nomeMes = "Fevereiro";
                    break;
                case 3:
                    nomeMes = "Março";
                    break;
                case 4:
                    nomeMes = "Abril";
                    break;
                case 5:
                    nomeMes = "Maio";
                    break;
                case 6:
                    nomeMes = "Junho";
                    break;
                case 7:
                    nomeMes = "Julho";
                    break;
                case 8:
                    nomeMes = "Agosto";
                    break;
                case 9:
                    nomeMes = "Setembro";
                    break;
                case 10:
                    nomeMes = "Outubro";
                    break;
                case 11:
                    nomeMes = "Novembro";
                    break;
                case 12:
                    nomeMes = "Dezembro";
                    break;
            }
        }else{
            switch (codmes){
                case 1:
                    nomeMes = "January";
                    break;
                case 2:
                    nomeMes = "February";
                    break;
                case 3:
                    nomeMes = "March";
                    break;
                case 4:
                    nomeMes = "April";
                    break;
                case 5:
                    nomeMes = "May";
                    break;
                case 6:
                    nomeMes = "June";
                    break;
                case 7:
                    nomeMes = "July";
                    break;
                case 8:
                    nomeMes = "August";
                    break;
                case 9:
                    nomeMes = "September";
                    break;
                case 10:
                    nomeMes = "October";
                    break;
                case 11:
                    nomeMes = "November";
                    break;
                case 12:
                    nomeMes = "December";
                    break;
            }
        }
        this.nomeMes = nomeMes;

    }
}
