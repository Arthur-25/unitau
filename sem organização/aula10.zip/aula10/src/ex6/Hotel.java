package ex6;

public class Hotel {
    public int dias;
    public double preco;
    public double valorS;

    public void calculaValor(){
        if (this.dias<15){
            this.preco = 250.00;
            this.valorS = 150.00;
        }else if (this.dias==15){
            this.preco = 220.00;
            this.valorS = 130.00;
        }else if (this.dias>15){
            this.preco = 180.00;
            this.valorS = 100.00;
        }
    }
}
