package ex6;

import java.util.Scanner;

public class ex6 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        Hotel H = new Hotel();
        System.out.println("Digite quantos dias vai ficar");
        H.dias = sc.nextInt();
        H.calculaValor();
        System.out.println("Valor da diaria: " + H.preco + " valor de serviços: " + H.valorS);
    }

}
