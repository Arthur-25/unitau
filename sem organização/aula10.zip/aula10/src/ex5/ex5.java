package ex5;

import java.util.Scanner;

public class ex5 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        Funcionario F = new Funcionario();
        System.out.print("Digite seu salario e seu cargo");
        F.salario = sc.nextDouble();
        F.cargo = sc.next();

        F.calculaSalario();
        System.out.println(F.salario);
    }
}
