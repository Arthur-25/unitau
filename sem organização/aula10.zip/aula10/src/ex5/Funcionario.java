package ex5;

public class Funcionario {
    public double salario;
    public String cargo;

    public void calculaSalario(){
        if (this.cargo.matches("Estagiario")){
            this.salario += (this.salario*10)/100;
        }
        if (this.cargo.matches("Junior")){
            this.salario += (this.salario*12)/100;
        }
        if (this.cargo.matches("Pleno")){
            this.salario += (this.salario*14)/100;
        }
        if (this.cargo.matches("Senior")){
            this.salario += (this.salario*16)/100;
        }
    }
}
