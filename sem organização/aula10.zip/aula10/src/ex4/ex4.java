package ex4;

import java.util.Scanner;

public class ex4 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        Hotel H = new Hotel();
        int D;
        double V;
        System.out.println("Digite a quantidade de dias e o valor da diaria");
        D = sc.nextInt();
        V = sc.nextDouble();

        H.calculapreco(D,V);
        System.out.print(H.preco);



    }
}
