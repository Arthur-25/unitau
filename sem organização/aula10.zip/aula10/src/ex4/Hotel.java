package ex4;

public class Hotel {
    public double preco;

    public void calculapreco(int dias, double valordiaria){
        this.preco = dias*valordiaria;

    }
}
