package ex2;

import java.util.Scanner;

public class ex2 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        ContaBancaria CB = new ContaBancaria();
        CB.saldo = 0;
        while (true) {
            System.out.println("Deseja depositar ou sacar? 1/2");
            int N = sc.nextInt();

            if (N == 1) {
                CB.depositar();
            } else if (N == 2) {
                CB.sacar();
            }else{
                break;
            }
            System.out.println(CB.saldo);
        }
    }
}
