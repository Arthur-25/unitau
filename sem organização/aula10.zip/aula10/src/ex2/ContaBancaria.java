package ex2;

import java.util.Scanner;

public class ContaBancaria {
    public double saldo;

    public void depositar(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um valor");
        double N = sc.nextDouble();

        this.saldo = this.saldo + N;
    }
    public void sacar(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um valor");
        double N = sc.nextDouble();

        this.saldo = this.saldo - N;
    }
    public  String escreve(){
        return "Valor atual na conta: " + this.saldo;
    }
}
