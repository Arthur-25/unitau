import java.util.Scanner;

public class ex2 {
    static int i;
    static double n1, n2, media;
    static Scanner valor = new Scanner(System.in);

    public static void main(String[] args)
    {
        for( i=1;i<=3;i++){
            ler_notas();
            mensagem(media);
        }
    }
    public static void ler_notas()
    {

        System.out.println("Informe o valor da 1º nota do "+i+"º aluno:");
        n1=valor.nextDouble();
        System.out.println("Informe o valor da 2º nota do "+i+"º aluno:");
        n2=valor.nextDouble();
    }
    public static double calcula_media()
    {
        media = (n1+n2)/2;
        return media;
    }
    public static void mensagem(double calc_media)
    {
        System.out.println("Valor da média calculada: "+calcula_media());
    }
}


