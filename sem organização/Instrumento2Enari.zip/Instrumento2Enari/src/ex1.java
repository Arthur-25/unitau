import java.util.Scanner;

public class ex1 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        int N = 1;

        while (N != 0){
            N = sc.nextInt();
            if (N!=0) System.out.println(funcaoConverter(N));
        }
    }
    public static int funcaoConverter(int N){
        String Nconvertido = String.valueOf(N);
        int contador = Nconvertido.length();
        int soma = 0;
        for (int i = 0;i<Nconvertido.length();i++){
            soma += Integer.parseInt(String.valueOf(Nconvertido.charAt(i))) * calculaFatorial(contador);
            contador --;
        }
        return soma;
    }
    public static int calculaFatorial(int N ){
        if (N>1) return N * calculaFatorial(N-1);
        else return 1;
    }
}
