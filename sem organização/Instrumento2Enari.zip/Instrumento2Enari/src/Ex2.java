import java.util.Scanner;

public class Ex2 {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext()){
                int N = sc.nextInt(), M = sc.nextInt();
                calculaResto(N, M);
        }
        sc.close();
    }
    public static void calculaResto(int N, int M){
        int fibN = funcaoFib(N);
        System.out.printf("%d \n", funcaoFib(fibN) % M);
    }
    public static int funcaoFib(int N){
            if (N > 2) return funcaoFib(N - 1) + funcaoFib(N - 2);
            else return 1;
    }
}
