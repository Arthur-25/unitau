import java.util.Scanner;

public class ex3 {
    public static void main(String[]args){
        int[] array = new int[100];
        int cont = 0;
        Scanner sc = new Scanner(System.in);
        int R, N;

        while (sc.hasNext()){
            R = sc.nextInt();
            N = sc.nextInt();

            array[cont] = calculaMmc(R,N);
            decideVencedor(calculaMmc(R,N));
            cont++;
        }
        cont --;
        for (int i = 0; i<100; i++){
            if (array[i] != 0){
                System.out.printf("%d ", array[cont]);
                cont--;
            }else{
                break;
            }
        }
        System.out.println();
    }
    public static void decideVencedor(int N){
        if (N>5){
            System.out.println("Noel");
        }else{
            System.out.println("Gnomos");
        }
    }
    public static int calculaMmc(int N1, int N2){
        if (N1>N2) return calculaMmc(N1-N2, N2);
        else if (N1<N2) return calculaMmc(N1, N2-N1);
        return N1;
    }
}
