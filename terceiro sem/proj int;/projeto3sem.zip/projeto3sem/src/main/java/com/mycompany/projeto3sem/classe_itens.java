/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto3sem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author arthur
 */
public class classe_itens {
    public int item_id;
    public String nome;
    public String desc;
    public int cat_id;
    public int quant;
    public String uni;

    private static final String URL = "jdbc:mysql://localhost:3306/projeto3semestre";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static Connection conexao;

    // Construtor
    public classe_itens(int id, String n, String d, int cat, int q, String u) {
        this.item_id = id;
        this.nome = n;
        this.desc = d;
        this.cat_id = cat;
        this.quant = q;
        this.uni = u;
    }

    // Construtor para quando o ID é gerado automaticamente (ao inserir)
    public classe_itens(String n, String d, int cat, int q, String u) {
        this.nome = n;
        this.desc = d;
        this.cat_id = cat;
        this.quant = q;
        this.uni = u;
    }

    public static Connection getConnection() throws SQLException {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conexao;
    }//fim da função que abre conexão

    public static void closeConnection() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
            conexao = null;
        }
    }//fim da função que fecha conexão

    public void inserir() {
        String sql = "INSERT INTO ITENS (nome, descricao, categoria_id, quantidade, unidade) VALUES (?, ?, ?, ?, ?)";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, desc);
            pstmt.setInt(3, cat_id);
            pstmt.setInt(4, quant);
            pstmt.setString(5, uni);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Item cadastrado com sucesso!");

        } catch (SQLException e) {
            System.err.println("Erro ao cadastrar item: " + e.getMessage());
        }
    }//fim da função inserir

    public static ArrayList<classe_itens> buscarTodos() {
        ArrayList<classe_itens> itens = new ArrayList<>();
        String sql = "SELECT item_id, nome, descricao, categoria_id, quantidade, unidade FROM ITENS";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                itens.add(new classe_itens(
                        rs.getInt("item_id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getInt("categoria_id"),
                        rs.getInt("quantidade"),
                        rs.getString("unidade")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todos os itens: " + e.getMessage());
        }
        return itens;
    }//fim função select todos

    public static void deletar(int id_item) {
        String sql = "DELETE FROM ITENS WHERE item_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, id_item);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Item deletado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum item encontrado com o ID fornecido para exclusão.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar item: " + e.getMessage());
        }
    }//fim da função deletar

    public void atualizar() {
        String sql = "UPDATE ITENS SET nome = ?, descricao = ?, categoria_id = ?, quantidade = ?, unidade = ? WHERE item_id = ?";
        String n = JOptionPane.showInputDialog("Digite o novo nome:");
        if (n != null && !n.trim().isEmpty()) {
            nome = n;
        }

        String d = JOptionPane.showInputDialog("Digite a nova descrição:");
        if (d != null) {
            desc = d;
        }

        String catStr = JOptionPane.showInputDialog("Digite o novo ID da categoria:");
        if (catStr != null && !catStr.trim().isEmpty()) {
            try {
                cat_id = Integer.parseInt(catStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ID da categoria inválido. A atualização deste campo foi ignorada.");
            }
        }

        String quantStr = JOptionPane.showInputDialog("Digite a nova quantidade:");
        if (quantStr != null && !quantStr.trim().isEmpty()) {
            try {
                quant = Integer.parseInt(quantStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Quantidade inválida. A atualização deste campo foi ignorada.");
            }
        }

        String u = JOptionPane.showInputDialog("Digite a nova unidade:");
        if (u != null && !u.trim().isEmpty()) {
            uni = u;
        }

        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, desc);
            pstmt.setInt(3, cat_id);
            pstmt.setInt(4, quant);
            pstmt.setString(5, uni);
            pstmt.setInt(6, item_id);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Item atualizado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum item encontrado com o ID fornecido para atualização.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar item: " + e.getMessage());
        }
    }//fim da função atualizar
}