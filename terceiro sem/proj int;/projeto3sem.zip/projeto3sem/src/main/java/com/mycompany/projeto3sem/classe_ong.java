/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto3sem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class classe_ong {
    private static final String URL = "jdbc:mysql://localhost:3306/projeto3semestre";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static Connection conexao;
    
    
    public  String nome;
    public  String endereco;
    public  String telefone;
    public  String email;
    public  int ong_id;
    
    //construtor
    public classe_ong(String n, String en, String t, String e, int o){
        nome = n;
        endereco = en;
        telefone = t;
        email = e;
        ong_id = o;
    }
    
    public static Connection getConnection() throws SQLException {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conexao;
    }//fim da função que abre conexão

    public static void closeConnection() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
            conexao = null;
        }
    }//fim da função que fecha conexão
    
    public  void inserir() {
        String sql = "INSERT INTO ONGS (nome, endereco, telefone, email) VALUES (?, ?, ?, ?)";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
            PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, endereco);
            pstmt.setString(3, telefone);
            pstmt.setString(4, email);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "ONG criada com sucesso!");
            
        } catch (SQLException e) {
            System.err.println("Erro ao criar cliente: " + e.getMessage());
        }
    }//fim da função inserir
    
    public static ArrayList<classe_ong> buscarTodos() {
        ArrayList<classe_ong> ongs = new ArrayList<>();
        String sql = "SELECT nome, endereco, telefone, email, ong_id FROM ONGS";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             Statement stmt = conexao.createStatement(); // Para SELECT sem parâmetros, Statement é suficiente
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ongs.add(new classe_ong(rs.getString("nome"), rs.getString("endereco"), rs.getString("telefone"), rs.getString("email"), rs.getInt("ong_id")));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todos os clientes: " + e.getMessage());
        }
        return ongs;
    }//fim função select todos
    
     public static void deletar(int id_ong) {
        String sql = "DELETE FROM ONGS WHERE ong_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, id_ong);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Ong deletado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma Ong encontrado com o ID fornecido para exclusão.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar cliente: " + e.getMessage());
        }
    }//fim da função deletar
     
     public  void atualizar() {
        String sql = "UPDATE ONGS SET nome = ?, endereco = ?, telefone = ?, email = ? WHERE ong_id = ?";
        String n = JOptionPane.showInputDialog("Digite um novo nome");
        if (!n.matches("")){
            nome = n;
        }
        
        String en = JOptionPane.showInputDialog("Digite um novo endereço");
        if (!en.matches("")){
            endereco = en;
        }
        
        String t = JOptionPane.showInputDialog("Digite um novo telefone");
        if (!t.matches("")){
            telefone = t;
        }
        
        String em = JOptionPane.showInputDialog("Digite um novo email");
        if (!em.matches("")){
            email = em;
        }
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, endereco);
            pstmt.setString(3, telefone);
            pstmt.setString(4, email);
            pstmt.setInt(5, ong_id);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Ong atualizada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma ong encontrado com o ID fornecido para atualização.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar cliente: " + e.getMessage());
        }
    }//fim da função atualizar
     
     
}
