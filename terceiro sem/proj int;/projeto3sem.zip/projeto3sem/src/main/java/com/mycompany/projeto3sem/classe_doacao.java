/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto3sem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author arthur
 */
public class classe_doacao {
    public int doacao_id;
    public Integer doador_id; // Pode ser nulo
    public int ong_id;
    public String data_doacao;
    public double valor;
    public String forma_pagamento;
    public String observacoes;

    private static final String URL = "jdbc:mysql://localhost:3306/projeto3semestre";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static Connection conexao;

    // Construtor
    public classe_doacao(int id, Integer doador, int ong, String data, double valorDoacao, String pagamento, String obs) {
        this.doacao_id = id;
        this.doador_id = doador;
        this.ong_id = ong;
        this.data_doacao = data;
        this.valor = valorDoacao;
        this.forma_pagamento = pagamento;
        this.observacoes = obs;
    }

    // Construtor para quando o ID é gerado automaticamente (ao inserir)
    public classe_doacao(Integer doador, int ong, String data, double valorDoacao, String pagamento, String obs) {
        this.doador_id = doador;
        this.ong_id = ong;
        this.data_doacao = data;
        this.valor = valorDoacao;
        this.forma_pagamento = pagamento;
        this.observacoes = obs;
    }

    public static Connection getConnection() throws SQLException {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conexao;
    }//fim da função que abre conexão

    public static void closeConnection() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
            conexao = null;
        }
    }//fim da função que fecha conexão

    public void inserir() {
        String sql = "INSERT INTO DOACOES_FINANCEIRAS (doador_id, ong_id, valor, forma_pagamento, observacoes) VALUES (?, ?, ?, ?, ?)";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setObject(1, doador_id == null ? null : doador_id); // Permite doador_id nulo
            pstmt.setInt(2, ong_id);
            pstmt.setDouble(3, valor);
            pstmt.setString(4, forma_pagamento);
            pstmt.setString(5, observacoes);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Doação financeira registrada com sucesso!");

        } catch (SQLException e) {
            System.err.println("Erro ao registrar doação financeira: " + e.getMessage());
        }
    }//fim da função inserir

    public static ArrayList<classe_doacao> buscarTodos() {
        ArrayList<classe_doacao> doacoes = new ArrayList<>();
        String sql = "SELECT doacao_id, doador_id, ong_id, data_doacao, valor, forma_pagamento, observacoes FROM DOACOES_FINANCEIRAS";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                doacoes.add(new classe_doacao(
                        rs.getInt("doacao_id"),
                        (Integer) rs.getObject("doador_id"), // Trata possível valor nulo
                        rs.getInt("ong_id"),
                        rs.getString("data_doacao"),
                        rs.getDouble("valor"),
                        rs.getString("forma_pagamento"),
                        rs.getString("observacoes")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todas as doações financeiras: " + e.getMessage());
        }
        return doacoes;
    }//fim função select todos

    public static void deletar(int id_doacao) {
        String sql = "DELETE FROM DOACOES_FINANCEIRAS WHERE doacao_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, id_doacao);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Doação financeira deletada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma doação financeira encontrada com o ID fornecido para exclusão.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar doação financeira: " + e.getMessage());
        }
    }//fim da função deletar

    public void atualizar() {
    String sql = "UPDATE DOACOES_FINANCEIRAS SET doador_id = ?, ong_id = ?, data_doacao = ?, valor = ?, forma_pagamento = ?, observacoes = ? WHERE doacao_id = ?";
    String doadorIdStr = JOptionPane.showInputDialog("Digite o novo ID do doador (deixe em branco para manter):");
    if (doadorIdStr != null && !doadorIdStr.trim().isEmpty()) {
        if (doadorIdStr.equals("0")) {
            doador_id = null;
        } else {
            try {
                doador_id = Integer.parseInt(doadorIdStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ID do doador inválido. A atualização deste campo foi ignorada.");
            }
        }
    }

    String ongIdStr = JOptionPane.showInputDialog("Digite o novo ID da ONG (deixe em branco para manter):");
    if (ongIdStr != null && !ongIdStr.trim().isEmpty()) {
        try {
            ong_id = Integer.parseInt(ongIdStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID da ONG inválido. A atualização deste campo foi ignorada.");
        }
    }

    String dataDoacaoStr = JOptionPane.showInputDialog("Digite a nova data da doação (AAAA-MM-DD HH:MM:SS) (deixe em branco para manter):");
    if (dataDoacaoStr != null && !dataDoacaoStr.trim().isEmpty()) {
        data_doacao = dataDoacaoStr;
    }

    String valorStr = JOptionPane.showInputDialog("Digite o novo valor da doação (deixe em branco para manter):");
    if (valorStr != null && !valorStr.trim().isEmpty()) {
        try {
            valor = Double.parseDouble(valorStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Valor da doação inválido. A atualização deste campo foi ignorada.");
        }
    }

    String formaPagamentoStr = JOptionPane.showInputDialog("Digite a nova forma de pagamento (deixe em branco para manter):");
    if (formaPagamentoStr != null) {
        forma_pagamento = formaPagamentoStr;
    }

    String obsStr = JOptionPane.showInputDialog("Digite as novas observações (deixe em branco para manter):");
    if (obsStr != null) {
        observacoes = obsStr;
    }

    try (Connection conexao = getConnection();
         PreparedStatement pstmt = conexao.prepareStatement(sql)) {
        pstmt.setObject(1, doador_id == null ? null : doador_id);
        pstmt.setInt(2, ong_id);
        pstmt.setString(3, data_doacao);
        pstmt.setDouble(4, valor);
        pstmt.setString(5, forma_pagamento);
        pstmt.setString(6, observacoes);
        pstmt.setInt(7, doacao_id);
        int linhasAfetadas = pstmt.executeUpdate();
        if (linhasAfetadas > 0) {
            JOptionPane.showMessageDialog(null, "Doação financeira atualizada com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Nenhuma doação financeira encontrada com o ID fornecido para atualização.");
        }
    } catch (SQLException e) {
        System.err.println("Erro ao atualizar doação financeira: " + e.getMessage());
    }
}//fim da função atualizar
}