/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto3sem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class classe_doadores {
    public int doador_id;
    public String nome;
    public String cpf_cnpj;
    public String endereco;
    public String telefone;
    public String email;

    private static final String URL = "jdbc:mysql://localhost:3306/projeto3semestre";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static Connection conexao;

    // Construtor
    public classe_doadores(int id, String n, String cpf, String end, String tel, String mail) {
        this.doador_id = id;
        this.nome = n;
        this.cpf_cnpj = cpf;
        this.endereco = end;
        this.telefone = tel;
        this.email = mail;
    }

    // Construtor para quando o ID é gerado automaticamente (ao inserir)
    public classe_doadores(String n, String cpf, String end, String tel, String mail) {
        this.nome = n;
        this.cpf_cnpj = cpf;
        this.endereco = end;
        this.telefone = tel;
        this.email = mail;
    }

    public static Connection getConnection() throws SQLException {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conexao;
    }//fim da função que abre conexão

    public static void closeConnection() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
            conexao = null;
        }
    }//fim da função que fecha conexão

    public void inserir() {
        String sql = "INSERT INTO DOADORES (nome, cpf_cnpj, endereco, telefone, email) VALUES (?, ?, ?, ?, ?)";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, cpf_cnpj);
            pstmt.setString(3, endereco);
            pstmt.setString(4, telefone);
            pstmt.setString(5, email);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Doador cadastrado com sucesso!");

        } catch (SQLException e) {
            System.err.println("Erro ao cadastrar doador: " + e.getMessage());
        }
    }//fim da função inserir

    public static ArrayList<classe_doadores> buscarTodos() {
        ArrayList<classe_doadores> doadores = new ArrayList<>();
        String sql = "SELECT doador_id, nome, cpf_cnpj, endereco, telefone, email FROM DOADORES";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                doadores.add(new classe_doadores(
                        rs.getInt("doador_id"),
                        rs.getString("nome"),
                        rs.getString("cpf_cnpj"),
                        rs.getString("endereco"),
                        rs.getString("telefone"),
                        rs.getString("email")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todos os doadores: " + e.getMessage());
        }
        return doadores;
    }//fim função select todos

    public static void deletar(int id_doador) {
        String sql = "DELETE FROM DOADORES WHERE doador_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, id_doador);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Doador deletado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum doador encontrado com o ID fornecido para exclusão.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar doador: " + e.getMessage());
        }
    }//fim da função deletar

    public void atualizar() {
        String sql = "UPDATE DOADORES SET nome = ?, cpf_cnpj = ?, endereco = ?, telefone = ?, email = ? WHERE doador_id = ?";
        String n = JOptionPane.showInputDialog("Digite o novo nome:");
        if (n != null && !n.trim().isEmpty()) {
            nome = n;
        }

        String cpf = JOptionPane.showInputDialog("Digite o novo CPF/CNPJ:");
        if (cpf != null && !cpf.trim().isEmpty()) {
            cpf_cnpj = cpf;
        }

        String end = JOptionPane.showInputDialog("Digite o novo endereço:");
        if (end != null && !end.trim().isEmpty()) {
            endereco = end;
        }

        String tel = JOptionPane.showInputDialog("Digite o novo telefone:");
        if (tel != null && !tel.trim().isEmpty()) {
            telefone = tel;
        }

        String mail = JOptionPane.showInputDialog("Digite o novo email:");
        if (mail != null && !mail.trim().isEmpty()) {
            email = mail;
        }

        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, cpf_cnpj);
            pstmt.setString(3, endereco);
            pstmt.setString(4, telefone);
            pstmt.setString(5, email);
            pstmt.setInt(6, doador_id);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Doador atualizado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum doador encontrado com o ID fornecido para atualização.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar doador: " + e.getMessage());
        }
    }//fim da função atualizar
}