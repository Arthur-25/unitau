/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto3sem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author arthur
 */
public class classe_categorias {
    public int categoria_id;
    public String nome;
    public String descricao;

    private static final String URL = "jdbc:mysql://localhost:3306/projeto3semestre";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static Connection conexao;

    // Construtor
    public classe_categorias(int id, String n, String desc) {
        this.categoria_id = id;
        this.nome = n;
        this.descricao = desc;
    }

    // Construtor para quando o ID é gerado automaticamente (ao inserir)
    public classe_categorias(String n, String desc) {
        this.nome = n;
        this.descricao = desc;
    }

    public static Connection getConnection() throws SQLException {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conexao;
    }//fim da função que abre conexão

    public static void closeConnection() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
            conexao = null;
        }
    }//fim da função que fecha conexão

    public void inserir() {
        String sql = "INSERT INTO CATEGORIAS (nome, descricao) VALUES (?, ?)";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, descricao);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Categoria cadastrada com sucesso!");

        } catch (SQLException e) {
            System.err.println("Erro ao cadastrar categoria: " + e.getMessage());
        }
    }//fim da função inserir

    public static ArrayList<classe_categorias> buscarTodos() {
        ArrayList<classe_categorias> categorias = new ArrayList<>();
        String sql = "SELECT categoria_id, nome, descricao FROM CATEGORIAS";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                categorias.add(new classe_categorias(
                        rs.getInt("categoria_id"),
                        rs.getString("nome"),
                        rs.getString("descricao")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todas as categorias: " + e.getMessage());
        }
        return categorias;
    }//fim função select todos

    public static void deletar(int id_categoria) {
        String sql = "DELETE FROM CATEGORIAS WHERE categoria_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, id_categoria);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Categoria deletada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma categoria encontrada com o ID fornecido para exclusão.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar categoria: " + e.getMessage());
        }
    }//fim da função deletar

    public void atualizar() {
        String sql = "UPDATE CATEGORIAS SET nome = ?, descricao = ? WHERE categoria_id = ?";
        String n = JOptionPane.showInputDialog("Digite o novo nome:");
        if (n != null && !n.trim().isEmpty()) {
            nome = n;
        }

        String desc = JOptionPane.showInputDialog("Digite a nova descrição:");
        if (desc != null) { // A descrição pode ser vazia
            descricao = desc;
        }

        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            pstmt.setString(2, descricao);
            pstmt.setInt(3, categoria_id);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Categoria atualizada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma categoria encontrada com o ID fornecido para atualização.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar categoria: " + e.getMessage());
        }
    }//fim da função atualizar
}