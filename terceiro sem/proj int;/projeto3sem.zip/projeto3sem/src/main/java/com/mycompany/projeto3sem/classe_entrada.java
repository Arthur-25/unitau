/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto3sem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author arthur
 */
public class classe_entrada {
    public int id;
    public int item_id;
    public int quant;
    public int doador_id;
    public int ong_id;
    public String obser;

    private static final String URL = "jdbc:mysql://localhost:3306/projeto3semestre";
    private static final String USUARIO = "root";
    private static final String SENHA = "";
    private static Connection conexao;

    // Construtor
    public classe_entrada(int id, int item, int quantidade, int doador, int ong, String obs) {
        this.id = id;
        this.item_id = item;
        this.quant = quantidade;
        this.doador_id = doador;
        this.ong_id = ong;
        this.obser = obs;
    }

    // Construtor para quando o ID é gerado automaticamente (ao inserir)
    public classe_entrada(int item, int quantidade, int doador, int ong, String obs) {
        this.item_id = item;
        this.quant = quantidade;
        this.doador_id = doador;
        this.ong_id = ong;
        this.obser = obs;
    }

    public static Connection getConnection() throws SQLException {
        if (conexao == null || conexao.isClosed()) {
            conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conexao;
    }//fim da função que abre conexão

    public static void closeConnection() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
            conexao = null;
        }
    }//fim da função que fecha conexão

    public void inserir() {
        String sql = "INSERT INTO ENTRADAS_ESTOQUE (item_id, quantidade, doador_id, ong_id, observacoes) VALUES (?, ?, ?, ?, ?)";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, item_id);
            pstmt.setInt(2, quant);
            pstmt.setInt(3, doador_id == 0 ? null : doador_id); // Permite doador_id nulo
            pstmt.setInt(4, ong_id);
            pstmt.setString(5, obser);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Entrada de estoque registrada com sucesso!");

        } catch (SQLException e) {
            System.err.println("Erro ao registrar entrada de estoque: " + e.getMessage());
        }
    }//fim da função inserir

    public static ArrayList<classe_entrada> buscarTodos() {
        ArrayList<classe_entrada> entradas = new ArrayList<>();
        String sql = "SELECT entrada_id, item_id, quantidade, doador_id, ong_id, observacoes FROM ENTRADAS_ESTOQUE";
        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                entradas.add(new classe_entrada(
                        rs.getInt("entrada_id"),
                        rs.getInt("item_id"),
                        rs.getInt("quantidade"),
                        rs.getInt("doador_id"),
                        rs.getInt("ong_id"),
                        rs.getString("observacoes")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar todas as entradas de estoque: " + e.getMessage());
        }
        return entradas;
    }//fim função select todos

    public static void deletar(int id_entrada) {
        String sql = "DELETE FROM ENTRADAS_ESTOQUE WHERE entrada_id = ?";
        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, id_entrada);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Entrada de estoque deletada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma entrada de estoque encontrada com o ID fornecido para exclusão.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar entrada de estoque: " + e.getMessage());
        }
    }//fim da função deletar

    public void atualizar() {
        String sql = "UPDATE ENTRADAS_ESTOQUE SET item_id = ?, quantidade = ?, doador_id = ?, ong_id = ?, observacoes = ? WHERE entrada_id = ?";
        String itemIdStr = JOptionPane.showInputDialog("Digite o novo ID do item:");
        if (itemIdStr != null && !itemIdStr.trim().isEmpty()) {
            try {
                item_id = Integer.parseInt(itemIdStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ID do item inválido. A atualização deste campo foi ignorada.");
            }
        }

        String quantStr = JOptionPane.showInputDialog("Digite a nova quantidade:");
        if (quantStr != null && !quantStr.trim().isEmpty()) {
            try {
                quant = Integer.parseInt(quantStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Quantidade inválida. A atualização deste campo foi ignorada.");
            }
        }

        String doadorIdStr = JOptionPane.showInputDialog("Digite o novo ID do doador (deixe em branco ou 0 para nulo):");
        if (doadorIdStr != null) {
            if (doadorIdStr.trim().isEmpty() || doadorIdStr.equals("0")) {
                doador_id = 0; // Representa nulo no banco de dados
            } else {
                try {
                    doador_id = Integer.parseInt(doadorIdStr);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "ID do doador inválido. A atualização deste campo foi ignorada.");
                }
            }
        }

        String ongIdStr = JOptionPane.showInputDialog("Digite o novo ID da ONG:");
        if (ongIdStr != null && !ongIdStr.trim().isEmpty()) {
            try {
                ong_id = Integer.parseInt(ongIdStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ID da ONG inválido. A atualização deste campo foi ignorada.");
            }
        }

        String obs = JOptionPane.showInputDialog("Digite as novas observações:");
        if (obs != null) {
            obser = obs;
        }

        try (Connection conexao = getConnection();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            pstmt.setInt(1, item_id);
            pstmt.setInt(2, quant);
            pstmt.setObject(3, doador_id == 0 ? null : doador_id); // Usa setObject para permitir nulo
            pstmt.setInt(4, ong_id);
            pstmt.setString(5, obser);
            pstmt.setInt(6, id);
            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Entrada de estoque atualizada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma entrada de estoque encontrada com o ID fornecido para atualização.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar entrada de estoque: " + e.getMessage());
        }
    }//fim da função atualizar
}