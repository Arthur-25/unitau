public class Node {
    private char x;
    private Node prox,ant;

    public Node(char valor){
        x = valor;
        prox = ant = null;
    }

    public void setX(char valor){
        x = valor;
    }

    public char getX(){
        return x;
    }

    public void setProx(Node n){
        prox = n;
    }

    public Node getProx(){
        return prox;
    }

    public void setAnt(Node n){
        ant = n;
    }

    public Node getAnt() {
        return ant;
    }
}
