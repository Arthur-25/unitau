public class Lista {
    private Node inicio,fim,head;

    public Lista(){
        inicio = fim = null;
        Node n = new Node('n');
        head = n;
    }

    public void addInicio(char valor){
        Node aux = new Node(valor);
        if (inicio!= null){
            aux.setProx(inicio);
            aux.setAnt(head);
            head.setProx(aux);
            inicio.setAnt(aux);
            inicio = aux;
        }else {
            fim = inicio = aux;
            fim.setProx(head);
            inicio.setAnt(head);
        }
    }

    public void addFim(char valor){
        Node aux = new Node(valor);
        if (fim!=null){
            aux.setAnt(fim);
            aux.setProx(head);
            fim.setProx(aux);
            head.setAnt(aux);
            fim = aux;
        }else {
            fim = inicio = aux;
            fim.setProx(head);
            inicio.setAnt(head);
        }
    }

    public void showFoward(){
        Node aux = inicio;
        while (aux!=head){
            System.out.print(aux.getX() + " ");
            aux = aux.getProx();
        }
        System.out.println();
    }

    public void showBackward(){
        Node aux = fim;
        while (aux != head){
            System.out.print(aux.getX() + " ");
            aux = aux.getAnt();
        }
        System.out.println();
    }

    public void removeValor(char c){
        Node aux = inicio;
        while (aux!=head){
            if (aux.getX() == c){
                if (aux == fim){
                    fim = aux.getAnt();
                }

                if (aux == inicio){
                    inicio = aux.getProx();
                }
                //o proximo do anterior é o proximo do atual
                aux.getAnt().setProx(aux.getProx());
                //o anterior do proximo é o anterior do atual
                aux.getProx().setAnt(aux.getAnt());
            }
            aux = aux.getProx();
        }
    }

    public Lista clone(){
        Node aux = fim;
        Lista l = new Lista();
        while (aux != head){
            l.addInicio(aux.getX());
            aux = aux.getAnt();
        }
        return l;
    }

    public void removeValores(char c){
        String cString = String.valueOf(c);
        c = Character.toLowerCase(c);

        Node aux = inicio;
        while (aux!=head){
            if (Character.toLowerCase(aux.getX())==c){
                removeValor(aux.getX());
            }
            aux = aux.getProx();
        }

    }

    public Lista inverteOrdem(){
        Node aux = fim;
        Lista L = new Lista();
        while (aux != head){
            L.addFim(aux.getX());
            aux = aux.getAnt();
        }
        return L;
    }

    public Node encontraMeio(){
        Node aux = inicio;
        String lista = "";
        while (aux!=head){
            lista += aux.getX();
            aux = aux.getProx();
        }


        String l = "";
        aux = inicio;
        while (aux!=head){
            if (l.length() == (lista.length()/2)-1){
                return aux;
            }
            l += aux.getX();
            aux = aux.getProx();
        }

        return null;
    }

    public String retornaSequencia(){
        Node aux = inicio;
        String lista = "";
        while (aux!=head){
            lista += aux.getX();
            aux = aux.getProx();
        }
        return lista;
    }

    public void addString(String s){
        Node aux = inicio;
        int cont = 0;
        while (aux!=head && cont<s.length()){
            addFim(s.charAt(cont));
            cont++;
            aux = aux.getProx();
        }
    }
}
