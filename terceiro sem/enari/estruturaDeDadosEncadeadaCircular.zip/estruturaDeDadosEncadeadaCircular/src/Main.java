public class Main {
    public static void main(String[]args){
        Lista l = new Lista();
        l.addFim('e');
        l.addInicio('a');
        l.addInicio('b');
        l.addInicio('c');
        l.addInicio('d');
        l.addFim('f');
        l.addFim('f');
        l.addFim('F');

        l.showFoward();
        l.showBackward();
        /*
        l.removeValor('f');
        l.showFoward();

        Lista L = l.clone();
        L.showFoward();


        l.removeValores('f');
        l.showFoward();
        l.showBackward();

         */

        l = l.inverteOrdem();
        l.showFoward();

        System.out.println(l.encontraMeio());
        System.out.println(l.retornaSequencia());

        l.addString("EstruturaDados");
        l.showFoward();
    }
}
