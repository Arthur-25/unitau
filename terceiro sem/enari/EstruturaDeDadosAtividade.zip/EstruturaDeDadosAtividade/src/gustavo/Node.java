package gustavo;
public class Node {
    // Node = nó

    private int x;
    private Node prox; //vai guardar o proximo n°

    public Node(int valor){
        x = valor;
        prox = null;
    }

    public void setX(int valor){
        x = valor;
    }

    public int getX(){
        return x;
    }

    public void setProx(Node p){
        prox = p;
    }

    public Node getProx(){
        return prox;
    }
}
