package gustavo;
public class MainAtividade {
    public static void main(String[] args) {
        Lista l = new Lista();

        l.add(10);
        l.add(20);
        l.add(30);
        l.add(40);
        l.show();
        System.out.println();

        // retorna quantidade de nós na lista
        System.out.println("quantidade de nós: " + l.contarNos()); // length
        System.out.println();

        // retorna soma do valor total na lista
        System.out.println("soma dos nós da lista: " + l.somarNos()); // soma
        System.out.println();

        // retorna maior valor armazenado na lista
        System.out.println("o maior número entre os nós: " + l.maiorNo()); // maior numero
        System.out.println();

        // retorna o menor valor armazenado na lista
        System.out.println("O menor número entre os nós: " + l.menorNo()); // menor numero
        System.out.println();

        // retorna os valores dobrados da lista
        System.out.println("lista em dobro: ");
        l.showDouble(); // mostra o dobro de cada nó
        System.out.println();

        // recebe um valor inteiro e retorna ele no inicio da lista
        System.out.println("valor novo adicionado no inicio da lista: ");
        l.addInicio(5); // insere n° no ínicio da lista
        l.show(); // verificar se foi inserido no inicio
        System.out.println();

        // retorna a soma dos valores que tem o indice impar dentro da lista
        System.out.println("somas impares: " + l.somaPosImpares()); // soma impar
        System.out.println();

        // retorna os numeros que estão nos indices pares dentro da lista
        l.posPares(); // valores dos nós que são pares
        System.out.println();

        // pesquisa a posição e retorna seu valor caso tenha
        System.out.println("pesquisando número da posição desejada...");
        System.out.println("-> " + l.posicao(2)); // procura valor do nó no indice desejado
        System.out.println();

        // remove valor na lista do indice recebido
        System.out.println("Removido valor do indice 2...");
        l.remove(2); // remove
        l.show(); // para confirmar se foi removido o valor que estava no indice colocado (no caso o 2)
        System.out.println();

        // retorna valor do nó retirado na lista e caso não exista posição retorna -999999
        l.removeVariacao(3); // variação do remove
        l.show(); // para confirmar se foi removido o valor que estava no indice colocado
        System.out.println();

        // insere ou substitui novo valor dentro da lista
        System.out.println("substituindo valor...");
        l.adicionarPos(0, 15); // coloca no inicio
        l.show(); // verificar se substituiu
        System.out.println();

        System.out.println("substituindo valor...");
        l.adicionarPos(2, 45); // substitui posição
        l.show(); // verificar se substituiu
        System.out.println();

        System.out.println("substituindo valor...");
        l.adicionarPos(5, 50); // coloca no fim da lista se valor for posterior ao ultimo no
        l.show(); // verificar se substituiu
    }
}
