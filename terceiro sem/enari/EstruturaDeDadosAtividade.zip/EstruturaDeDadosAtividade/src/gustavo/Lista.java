package gustavo;
public class Lista {
    Node inicio;
    Node fim;
    public Lista (){
        inicio = fim = null;
    }
    public int contarNos (){
        int contador = 0;
        Node aux = inicio;

        while (aux != null){
            contador++;
            aux = aux.getProx();
        }
        return contador;
    }
    public int somarNos (){
        int soma = 0;
        Node aux = inicio;

        while (aux != null){
            soma += aux.getX();
            aux = aux.getProx();
        }
        return soma;
    }
    public int maiorNo (){
        int maior = inicio.getX(); // valor 1° nó
        Node aux = inicio.getProx();

        while (aux != null){
            if (aux.getX() > maior){
                maior = aux.getX();
            }
            aux = aux.getProx();
        }
        return maior;
    }
    public int menorNo (){
        int menor = inicio.getX();
        Node aux = inicio.getProx();

        while (aux != null){
            if (aux.getX() < menor){
                menor = aux.getX();
            }
            aux = aux.getProx();
        }

        return menor;
    }
    public void add (int valor){
        if (inicio == null){
            inicio = new Node(valor);
            fim = inicio;
        } else {
            fim.setProx(new Node(valor));
            fim = fim.getProx();
        }
    }

    public int remove (int indice){
        if (indice < 0){
            System.out.println("não existe esse indíce.");
            return - 1;
        }

        if (indice == 0){
            int valorRemovido = inicio.getX();
            inicio = inicio.getProx();

            if (inicio == null){
                fim = null;
            }
            return valorRemovido;
        }

        Node anterior = inicio;
        Node atual = inicio.getProx();
        int contador = 1;

        while (atual != null && contador < indice){
            anterior = atual;
            atual = atual.getProx();
            contador++;
        }

        if (atual == null){
            System.out.println("indíce fora de alcançe.");
            return -1;
        }

        anterior.setProx(atual.getProx());

        if (atual == fim){
            fim = anterior;
        }

        return atual.getX();
    }

    public void removeVariacao (int indice){
        if (indice < 0){
            System.out.println("-999999");
        }

        if (indice == 0){
            inicio = inicio.getProx();

            if (inicio == null){
                fim = null;
            }
        }

        Node anterior = inicio;
        Node atual = inicio.getProx();
        int contador = 1;

        while (atual != null && contador < indice){
            anterior = atual;
            atual = atual.getProx();
            contador++;
        }

        if (atual == null){
            System.out.println("indíce fora de alcançe.");
        }

        anterior.setProx(atual.getProx());

        if (atual == fim){
            fim = anterior;
        }

        System.out.println("valor removido: " + atual.getX() + " do indíce " + indice);
    }

    public int adicionarPos (int pos, int valor){
        Node aux = new Node(valor);

        if (pos == 0){
            aux.setProx(inicio);
            inicio = aux;

            if (fim == null){
                fim = aux;
            }
            return 0;
        }

        Node atual = inicio;

        // Percorrer até a posição anterior
        for (int i = 0; i < pos - 1 && atual != null; i++) {
            atual = atual.getProx();
        }

        if (atual == null){
            System.out.println("não existe essa posição");
            return -1;
        }

        aux.setProx(atual.getProx());
        atual.setProx(aux);

        if (aux.getProx() == null){
            fim = aux;
        }

        return 0;
    }
    public void addInicio(int valor){
        Node aux = new Node(valor);
        if (inicio != null){
            aux.setProx(inicio);
            inicio = aux;
        } else {
            inicio = fim = aux;
        }
    }
    public void showDouble () {
        int contador = 0;
        Node aux = inicio;

        while (aux != null){
            contador++;
            System.out.println("dobro do " + contador + "° nó: " + aux.getX() * 2);
            aux = aux.getProx();
        }
    }
    public int somaPosImpares (){
        int soma = 0;
        int cont = 0;

        Node aux = inicio;

        while (aux != null){
            if (cont % 2 != 0){
                soma += aux.getX();
            }
            aux = aux.getProx();
            cont++;
        }
        return soma;
    }
    public void posPares (){
        int cont = 0;

        Node aux = inicio;

        System.out.println("Valores pares: ");

        while (aux != null){
            if (cont % 2 == 0){
                System.out.println("na posição " + cont + " contém o número " +  aux.getX());
            }
            aux = aux.getProx();
            cont++;
        }
    }

    public int posicao (int pos){
        Node aux = inicio;
        int contador = 0;

        while (aux != null){
            if (contador == pos){
                return aux.getX();
            }
            contador++;
            aux = aux.getProx();
        }

        System.out.println("não existe nenhum número na posicão + " + pos);
        return - 1;
    }

    public void show (){
        Node aux = inicio;

        while (aux != null){
            System.out.println(aux.getX());
            aux = aux.getProx();
        }
    }

}
