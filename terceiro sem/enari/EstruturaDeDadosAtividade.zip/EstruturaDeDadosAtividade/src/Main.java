public class Main {
    public static void main(String[]args){
        Lista l = new Lista();

        l.add(10);
        l.add(20);
        l.add(30);
        l.add(40);
        l.add(70);
        l.add(80);

        /*
        l.show();
        System.out.println();
        System.out.println(l.length());
        System.out.println(l.soma());
        System.out.println(l.maior());
        System.out.println(l.menor());

        System.out.println();
        l.doubleX();
        l.show();

        System.out.println();
        l.addInicio(50);
        l.addInicio(60);
        l.addInicio(70);
        l.show();
        */
        l.show();
        System.out.println();
        //l.posPares();

        //System.out.println(l.encontraPos(0));
        //l.removePos(2);
        //System.out.println(l.valRemovido(2));
        l.inserePos(2,50);
        l.show();
    }
}
