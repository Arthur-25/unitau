package duplamente;

public class Main {
	public static void main(String[] args){
		ListaDLL l = new ListaDLL();
		
		l.addFim(10);
		l.addFim(20);
		l.addFim(30);
		l.addFim(40);
		
		l.addInicio(50);
		l.addInicio(60);

		//Retorne a quantidade de nós da lista (length)
		System.out.println("Quantidade de nós da lista = "+l.length());
		l.showFoward();

		//Retorne a soma dos valores armazenados na lista (total)
		System.out.println("Soma dos valores nos nós da lista = "+l.total());
		l.showFoward();

		//Retorne o maior valor armazenado na lista (max)
		System.out.println("Maior valor da lista = "+l.max());

		//Retorne o menor valor armazenado na lista (min)
		System.out.println("Menor valor da lista = " + l.min());
		l.showFoward();

		//Escreva o método doubleX() que deve dobrar os valores armazenados na lista.
		System.out.println("Antes de dobrar os valores");
		l.showFoward();
		l.doubleX();
		System.out.println("Depois de dobrar os valores");
		l.showFoward();

		//Recebe um valor inteiro (valor) como parâmetro e o insere no início da lista
		//(addInicio)

		l.addInicio(70);

		//Escreva o método int somaPosImpares(), que fará a soma dos valores dos nós nas
		//posições ímpares da lista encadeada. Considere que o Início está na posição 0,
		//como se fosse um vetor.

		System.out.println("Soma dos valores em posições impares = " + l.somaPosImpares());

		//Escreva o método void posPares() que deve exibir na tela os nós das posições
		//pares da lista.
		l.showFoward();
		System.out.println("Valores em posições pares da lista: ");
		l.posPares();

		//Recebe um valor inteiro (pos) como parâmetro e retorna o valor armazenado no nó
		//cuja posição seja igual a pos. Considere que o início da lista ocupa a posição 0.

		System.out.println("Valor da posição 2 na lista: ");
		System.out.println(l.retornaValPos(2));
		l.showFoward();

		//Recebe um valor inteiro (pos) como parâmetro e remove o nó da lista que
		//corresponde a essa posição. Caso essa posição não exista, deve exibir na tm ela
		//uma mensagem de erro: “Posição não existe”
		System.out.println("Antes de remover da posição 2:");
		l.showFoward();
		l.removePos(2);
		System.out.println("Depois de remover:");
		l.showFoward();

		//Construa uma variação para o método do exercício 10 que retorna o valor do nó
		//retirado da lista. Caso a posição não exista, deve retornar o valor -999999.

		System.out.println("Antes de remover da posição 3:");
		l.showFoward();
		System.out.println("Valor removido = " + l.removePosVal(3));
		l.removePos(3);
		System.out.println("Depois de remover:");
		l.showFoward();

		// Construa os métodos inserePos(posição, valor) que faça a inserção do valor na
		//posição indicada por posição. Note que se a posição for posterior ao último nó da
		//lista, o método deve inserir esse valor como se fosse o último. Caso a posição seja
		//0, deve inserir o valor como se fosse o primeiro nó da lista e nos demais casos,
		//deve inserir entre dois nós, refazendo as ligações do novo nó com os nós anterior
		//e posterior.

		System.out.println("Adicionando no começo valor 5:");
		l.showFoward();
		l.inserePos(0,5);
		l.showFoward();

		System.out.println("Adicionando no fim valor 45:");
		l.inserePos(l.length(),45);
		l.showFoward();

		System.out.println("Adicionando na posição 2:");
		l.inserePos(2,11);
		l.showFoward();

		System.out.println("Adicionando na posição 7:");
		l.inserePos(7,33);
		l.showFoward();

	}
}