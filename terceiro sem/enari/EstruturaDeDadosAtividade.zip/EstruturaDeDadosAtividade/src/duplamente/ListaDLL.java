package duplamente;

public class ListaDLL {
	private NodeDLL inicio, fim;
	
	public ListaDLL(){
		inicio = fim = null;
	}
	
	public void addFim(int valor){
		NodeDLL aux = new NodeDLL(valor);
		if(inicio!=null){
			fim.setProx(aux);
			aux.setAnt(fim);
			fim = aux;
		}
		else{
			inicio = fim = aux;
		}
	}//fim da função que adiciona valores no fim da lista
	
	public void addInicio(int valor){
		NodeDLL aux = new NodeDLL(valor);
		if(inicio!=null){
			inicio.setAnt(aux);
			aux.setProx(inicio);
			inicio = aux;
		}
		else{
			inicio = fim = aux;
		}
	}//fim da função que adiciona valores no começo da lista
	
	public void showFoward(){
		NodeDLL aux = inicio;
		
		while(aux!=null){
			System.out.print(aux.getX() + "  ");
			aux = aux.getProx();
		}
		System.out.println();
	}//fim da função que imprime lista do começo até o fim
	
	public void showBackward(){
		NodeDLL aux = fim;
		
		while(aux!=null){
			System.out.print(aux.getX() + "  ");
			aux = aux.getAnt();
		}
		System.out.println();
	}//fim da função que imprime a lista do fim até o começo

	public int length(){
		NodeDLL aux = inicio;
		int contador = 0;
		while(aux!=null){
			contador++;
			aux = aux.getProx();
		}
		return contador;
	}//fim da lista que retorna o tamanho da lista

	public int total(){
		NodeDLL aux = inicio;
		int soma = 0;
		while(aux!=null){
			soma+= aux.getX();
			aux = aux.getProx();
		}
		return soma;
	}//fim da lista que retorna a soma dos valores da lista

	public int max(){
		NodeDLL aux = inicio;
		int maior = inicio.getX();
		while(aux!=null){
			if (aux.getX()>maior){
				maior = aux.getX();
			}
			aux = aux.getProx();
		}
		return maior;
	}//fim da lista que retorna o maior numero na lista

	public int min(){
		NodeDLL aux = inicio;
		int menor = inicio.getX();
		while(aux!=null){
			if (aux.getX()<menor){
				menor = aux.getX();
			}
			aux = aux.getProx();
		}
		return menor;
	}//fim da lista que retorna o menor numero na lista

	public void doubleX(){
		NodeDLL aux = inicio;

		while(aux!=null){
			aux.setX(aux.getX()*2);
			aux = aux.getProx();
		}
	}//fim da função que dobra os valores na lista

	public int somaPosImpares(){
		NodeDLL aux = inicio;
		int soma = 0,cont = 0;
		while(aux!=null){

			aux = aux.getProx();
			if (cont%2!=0){
				soma+= aux.getX();
			}
			cont++;
		}
		return soma;
	}//fim da função que retorna a soma dos valores em posições impares da lista

	public void  posPares(){
		NodeDLL aux = inicio;
		int cont = 0;
		while(aux!=null){
			if (cont%2==0){
				System.out.print(aux.getX() + "  ");
			}

			cont++;
			aux = aux.getProx();
		}
		System.out.println();
	}//fim da função que exibe os valores em posições pares da lista

	public int retornaValPos(int pos){
		NodeDLL aux = inicio;
		int cont = 0,valor = -1;
		while(aux!=null){
			if (cont==pos){
				valor= aux.getX();
			}
			cont++;
			aux = aux.getProx();
		}
		return valor;
	}//fim da função que retorna o valor de uma posição

	public void removePos(int pos){
		if (pos<0 || pos>=length()){
			System.out.println("Posição não existe");
		}else {
			NodeDLL aux = inicio;
			int cont = 0;
			while (aux != null) {
				if (cont == pos) {
					aux.getAnt().setProx(aux.getProx());
				}
				cont++;
				aux = aux.getProx();
			}
		}
	}//fim da função que remove um nó da lista

	public int removePosVal(int pos){
		if (pos<0 || pos>=length()){
			return -999999;
		}else {
			NodeDLL aux = inicio;
			int cont = 0,val = 0;
			while (aux != null) {
				if (cont == pos) {
					val = aux.getX();
					removePos(pos);
				}
				cont++;
				aux = aux.getProx();
			}
			return val;
		}
	}//fim da função que remove um nó da lista e imprime o valor removido

	public void inserePos(int pos, int val) {
		if (pos == 0) {
			addInicio(val);
		} else if (pos >= length()) { // Se a posição for maior ou igual ao tamanho, insere no final
			addFim(val);
		} else if (pos > 0 && pos < length()) {
			NodeDLL aux = inicio;
			int cont = 0;
			while (aux != null && cont < pos) {
				aux = aux.getProx();
				cont++;
			}

			if (aux != null) { // 'aux' agora está no nó da posição 'pos'
				NodeDLL novoNode = new NodeDLL(val);
				novoNode.setProx(aux);
				novoNode.setAnt(aux.getAnt());
				aux.getAnt().setProx(novoNode);
				aux.setAnt(novoNode);
			}
		}
	}//fim da função que adiciona valores em posições especificas
}