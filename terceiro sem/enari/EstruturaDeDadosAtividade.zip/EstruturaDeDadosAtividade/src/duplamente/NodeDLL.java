package duplamente;

public class NodeDLL {
	private int x;
	private NodeDLL prox, ant;
	
	public NodeDLL(int valor){
		x = valor;
		prox = ant = null;
	}
	
	public void setX(int valor){
		x = valor;
	}
	
	public int getX(){
		return x;
	}
	
	public void setProx(NodeDLL p){
		prox = p;
	}
	
	public NodeDLL getProx(){
		return prox;
	}
	
	public void setAnt(NodeDLL p){
		ant = p;
	}
	
	public NodeDLL getAnt(){
		return ant;
	}
}