public class Lista {
    public Node inicio;
    public Node fim;

    public Lista() {
        inicio = fim = null;
    }

    public void add(int valor) {
        //se a lista estiver vazia
        if (inicio == null) {
            //um node novo é criado que se torna o começo e o fim da lista
            inicio = new Node(valor);
            fim = inicio;
        } else {
            //senão cria um novo node apos o fim e torna o fim o node criado deixando um node para tras
            fim.setProx(new Node(valor));
            fim = fim.getProx();
        }
    }//fim função que adiciona novo valor no final da lista

    public void show() {
        //variavel que vai ser usada para percorrer os nodes existentes
        Node aux = inicio;
        //enquanto a variavel não for um null
        while (aux != null) {
            //pega o valor dentro do node atual e imprime
            System.out.println(aux.getX());
            //passa para o proximo node
            aux = aux.getProx();
        }
    }//fim da função que mostra todos os valores dentro dos nodes

    public int length() {
        int n = 0;
        Node aux = inicio;
        while (aux != null) {
            n++;
            aux = aux.getProx();
        }
        return n;
    }//fim função que retorna a quantidade de nodes da lista

    public int soma() {
        int som = 0;
        Node aux = inicio;
        while (aux != null) {
            som += aux.getX();
            aux = aux.getProx();
        }
        return som;
    }//fim da função que retorna soma dos valores na lista

    public int maior() {
        Node aux = inicio;
        int maior = inicio.getX();
        while (aux != null) {
            if (aux.getX() > maior) {
                maior = aux.getX();
            }
            aux = aux.getProx();
        }
        return maior;
    }//fim da função que retorna o maior numero na lista

    public int menor() {
        Node aux = inicio;
        int menor = inicio.getX();
        while (aux != null) {

            if (aux.getX() < menor) {
                menor = aux.getX();
            }
            aux = aux.getProx();
        }
        return menor;
    }//fim da função que retorna o menor numero na lista

    public void doubleX() {
        Node aux = inicio;

        while (aux != null) {
            aux.setX(aux.getX() * 2);
            aux = aux.getProx();
        }
    }//fim da função que dobra os valores na lista

    public void addInicio(int valor) {
        fim.setProx(new Node(fim.getX()));
        fim = fim.getProx();

        Node aux = inicio;
        int cont = 0;
        int atual = aux.getX(), proximo;
        while (aux != null && cont != length() - 1) {
            //salva o valor do proximo
            proximo = aux.getProx().getX();
            //transforma o proximo no atual
            aux.getProx().setX(atual);
            //o atual se torna o proximo
            atual = proximo;
            aux = aux.getProx();
            cont++;
        }
        inicio.setX(valor);
    }//fim da função que adiciona no começo da lista

    public int somaPosImpares() {
        int soma = 0, cont = 0;
        Node aux = inicio;

        while (aux != null) {
            if (cont % 2 != 0) {
                soma += aux.getX();
            }
            cont++;
            aux = aux.getProx();
        }
        return soma;
    }//fim função que retorna soma dos numeros em posições impares

    public void posPares() {
        int cont = 0;
        Node aux = inicio;

        while (aux != null) {
            if (cont % 2 == 0) {
                System.out.println(aux.getX());
            }
            cont++;
            aux = aux.getProx();
        }

    }//fim função que imprime valores nas posições pares

    public int encontraPos(int pos) {
        int cont = 0, val = -1;
        Node aux = inicio;

        while (aux != null) {
            if (cont == pos) {
                val = aux.getX();
            }

            cont++;
            aux = aux.getProx();
        }
        //val -1 significa que não encontrou a posição
        return val;
    }//fim da função que retorna valor de uma posição especifica

    public void removePos(int pos) {
        int cont = 0;
        Node aux = inicio;
        Node atual, proximo;
        if (pos < 0 || pos >= length()) {
            System.out.println("Posição invalida");
        } else{
            while (aux != null && cont < length()) {
                if (cont == pos - 1) {
                    aux.setProx(aux.getProx().getProx());
                }
                cont++;
                aux = aux.getProx();

            }
        }
    }//fim da função que remove valor dependendo da posição

    public int valRemovido(int pos) {
        int cont = 0;
        Node aux = inicio;
        Node atual, proximo;
        int val = 0;
        if (pos < 0 || pos >= length()) {
            System.out.println("Posição invalida");
            val = -999999;
        } else{
            while (aux != null && cont < length()) {
                if (cont == pos - 1) {
                    val = aux.getProx().getX();
                    aux.setProx(aux.getProx().getProx());
                }
                cont++;
                aux = aux.getProx();
            }
        }
        return val;
    }//fim da função que retorna um valor removido

    public void inserePos(int pos, int val){
        Node aux = inicio;
        int cont = 0;
        while (aux != null && cont != length()-1) {
            if (cont == pos-1){
               Node n = new Node(val);
               n.setProx(aux.getProx());
               aux.setProx(n);
            }
            cont++;
            aux = aux.getProx();
        }
    }//fim da função que adiciona um valor em uma posição

}
