public class ex13 {
    public static int F(int x){
        if (x%3==0) return x*x;
        else if (x%3==1) return x+3;
        else return x;
    }
    public static void main(String[]args){

    }
}
