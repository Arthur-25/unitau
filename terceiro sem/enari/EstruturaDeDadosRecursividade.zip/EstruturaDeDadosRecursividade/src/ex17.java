public class ex17 {
    public static int F(int N){
        if (N < 4) return 3*N;
        else return 2 * F(N - 4) + 5;
    }
    public static void main(String[]args){
        System.out.println(F(3)); //saida 9
        System.out.println(F(7)); //saida 23
    }
}
