public class ex11 {
    public static int MOD(int n, int m){
        if (n>=m) return MOD(n-m,m);
        else  return n;
    }
    public static void main(String[]args){
        System.out.println(MOD(6,4));
    }
}
