public class ex16 {
    public static double s(int n){
        if (n==1) return 1;
        else  {
            System.out.println("Valor de n = " + n + " 1/n = " +  1.0/n);
            if (n%2==0) return -(1.0 / n) + s(n - 1);
            else  return  (1.0/n) + s(n-1);
        }
    }
    public static void main(String[]args){
        System.out.println(s(4));
    }
}
