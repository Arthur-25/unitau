public class ex12 {
    private static String decimalHexaRecursivo(int n) {
        String DIGITOS_HEXA = "0123456789ABCDEF";
        // Caso base da recursão: Se o número for menor que 16,
        // ele é um único dígito hexadecimal.
        if (n < 16) {
            return String.valueOf(DIGITOS_HEXA.charAt(n));
        } else {
            // Passo recursivo:
            // 1. Calcula o resto da divisão por 16. Este é o dígito hexadecimal atual.
            int resto = n % 16;
            // 2. Chama recursivamente com o quociente (n / 16) para obter os dígitos anteriores.
            // 3. Concatena os dígitos anteriores com o dígito hexadecimal atual.
            return decimalHexaRecursivo(n / 16) + DIGITOS_HEXA.charAt(resto);
        }
    }
    public static void main(String[]args){
        System.out.println("Decimal 10 para Hexa: " + decimalHexaRecursivo(10));   // Saída: A
        System.out.println("Decimal 255 para Hexa: " + decimalHexaRecursivo(255)); // Saída: FF
        System.out.println("Decimal 256 para Hexa: " + decimalHexaRecursivo(256)); // Saída: 100
        System.out.println("Decimal 0 para Hexa: " + decimalHexaRecursivo(0));     // Saída: 0
        System.out.println("Decimal 4095 para Hexa: " + decimalHexaRecursivo(4095)); // Saída: FFF
        System.out.println("Decimal 16 para Hexa: " + decimalHexaRecursivo(16));   // Saída: 10
        System.out.println("Decimal 1 para Hexa: " + decimalHexaRecursivo(1));     // Saída: 1
    }
}
