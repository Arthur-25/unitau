public class ex8 {
    public static int MDC(int x,int y){
        if (x>y) return MDC(x-y,y);
        if (x==y) return x;
        else return MDC(y,x);
    }
    public static void main(String[]args){
        System.out.println(MDC(12,24));
    }
}
