public class ex7 {
    public static int h(int m, int n){
        if (n==1) return m+1;
        else if (m==1) return n+1;
        else if (m>1 && n>1) return h(m,n - 1) + h( m - 1,n);
        return 1;
    }
    public static void main(String[]args){
        System.out.println(h(2,2));
    }
}
