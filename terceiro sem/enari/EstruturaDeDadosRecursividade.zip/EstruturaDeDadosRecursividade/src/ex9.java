public class ex9 {
    public static int NX(int n, int x){
        if (n>0 && x>0) return n*x;
        else if (n==0 || x==0) return 0;
        else return 1;
    }
    public static void main(String[]args){
        System.out.println(NX(3,8));
    }
}
