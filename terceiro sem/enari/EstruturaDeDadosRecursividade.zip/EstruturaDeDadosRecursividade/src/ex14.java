public class ex14 {
    //Letra A a função puzzle multiplica os numeros de base até o limite
    public static int puzzle(int base, int limit)
    { //base and limit are nonnegative numbers
        if ( base > limit ) return -1;
        else if ( base == limit ) return 1;
        //Letra B recursiva ocorre aqui
        else return base * puzzle(base + 1, limit);
    }
    public static void main(String[]args){
        System.out.println(puzzle(14,10)); //-1
        System.out.println(puzzle(4,7)); //120
        System.out.println(puzzle(0,0)); //1
    }
}
