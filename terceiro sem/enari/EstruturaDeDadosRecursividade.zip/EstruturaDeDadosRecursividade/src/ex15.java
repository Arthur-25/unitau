public class ex15 {
    public static double sum(int n){
        if (n==1) return 1;
        else  {
            System.out.println("Valor de n = " + n + " 1/n = " +  1.0/n);
            return  (1.0/n) + sum(n-1);
        }
    }
    public static void main(String[]args){
        System.out.println(sum(3));
    }
}
