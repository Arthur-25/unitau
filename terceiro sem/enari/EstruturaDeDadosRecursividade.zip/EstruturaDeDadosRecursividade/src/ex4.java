public class ex4 {
    public static int somaRep(int a, int b){
        int soma = 0;
        //calculo para A
        //if A positivo
        if (a>0) {
            for (int i = 0; i < a; i++) {
                soma++;
            }
            //if A negativo
        } else if(a<0){
            for (int i = 0; i > a; i--) {
                soma--;
            }
        }
        //calculo para B
        //if B positivo
        if (b>0) {
            for (int i = 0; i < b; i++) {
                soma++;
            }
            //if b negativo
        }else if(b<0){
            for (int i = 0; i > b; i--) {
                soma--;
            }
        }
        return soma;
    }//fim da função
    public static int soma(int a, int b){
        if (b==0) return a;
        else return soma(a+1,b-1);
    }
    public static void main(String[]args){
        System.out.println(somaRep(20,40));
        System.out.println(somaRep(-20,40));
        System.out.println(somaRep(20,-40));

        System.out.println(soma(40,20));
    }
}
