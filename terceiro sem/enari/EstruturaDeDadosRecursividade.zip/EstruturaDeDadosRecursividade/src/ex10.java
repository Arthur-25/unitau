public class ex10 {
    public static int somaImpar(int n){
        if (n%2!=0 && n>0) return n + somaImpar(n-1);
        else if (n%2==0) return somaImpar(n-1);
        else return 0;

    }
    public static void main(String[]args){
        System.out.println(somaImpar(6));
    }
}
