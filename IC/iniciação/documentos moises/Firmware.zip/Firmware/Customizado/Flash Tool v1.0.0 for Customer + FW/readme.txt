Futher instructions to flash the custom firmware:

WHEN USING USB-TO-TTL CABE, USE ONLY THE TWO RX/TX WIRES; DO NOT USE THE TTL VCC/GND; POWER THE GPS USING EXTERNAL BATTERY.

Using FlashTool v1.0.0 (NOT ANY NEWER VERSION)

Series: 3329 [3339 is not available]

Download Agent: MTK_AllInOne_DA_MT3339_E3.bin

ROM: AXN2.10_5196_3339_1152.1111100.10.bin

ComPort: 6

Baudrate: 9600

Connect

"Download" [sic., it actually uploads the new firmware into the board]

See PDF doc for details.

THE NMEA BAUD RATE WILL BE CHANGED FROM 9600 TO 115200!
